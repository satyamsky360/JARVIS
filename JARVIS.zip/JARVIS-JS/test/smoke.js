// End-to-end smoke test (needs `npm install`). Usage: start the server (npm start), then `npm run test:e2e`
// Optional: BASE_URL=http://localhost:3000 HOST_USER=host HOST_PASS=jarvis@123 INGEST_API_KEY=<a key from INGEST_API_KEYS> npm run test:e2e
// WARNING: this test calls DELETE /api/reset. Start the server with DB_PATH=:memory: (or a scratch file) so your real history is not wiped.
const fs = require("fs"), path = require("path");
const BASE = process.env.BASE_URL || "http://localhost:3000";
let cookie = "", failed = 0;
const ok = (cond, msg) => { console.log((cond ? "PASS " : "FAIL ") + msg); if (!cond) failed++; };

async function call(method, url, body, raw) {
  const opt = { method, headers: { cookie } };
  if (body && !raw) { opt.headers["Content-Type"] = "application/json"; opt.body = JSON.stringify(body); }
  if (raw) opt.body = raw;
  const r = await fetch(BASE + url, opt);
  const text = await r.text(); let json = null; try { json = JSON.parse(text); } catch (_) {}
  return { status: r.status, json, text, headers: r.headers };
}
const upload = (name, content) => { const fd = new FormData(); fd.append("logfile", new Blob([content]), name); return call("POST", "/api/logs", null, fd); };

(async () => {
  let r = await call("GET", "/api/dashboard"); ok(r.status === 401, "API requires sign-in");
  r = await fetch(BASE + "/api/login", { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: process.env.HOST_USER || "host", password: process.env.HOST_PASS || "jarvis@123" }) });
  cookie = (r.headers.get("set-cookie") || "").split(";")[0]; ok(r.status === 200 && cookie, "login works");

  await call("DELETE", "/api/reset");
  r = await call("GET", "/api/dashboard"); ok(r.status === 200 && r.json.incidents.length === 0 && r.json.metrics.eventsAnalyzed === 0, "empty state after reset");

  const dir = path.join(__dirname, "..", "sample-data");
  r = await upload("01-payment-outage.log", fs.readFileSync(path.join(dir, "01-payment-outage.log")));
  ok(r.status === 200 && r.json.parsed > 20, "upload .log parsed " + (r.json && r.json.parsed));
  r = await upload("01-payment-outage.log", fs.readFileSync(path.join(dir, "01-payment-outage.log")));
  ok(r.json && r.json.added === 0 && r.json.duplicates > 0, "re-upload is de-duplicated");
  r = await call("GET", "/api/dashboard"); const inc = r.json.incidents[0];
  ok(inc && inc.rootCause === "database", "DB outage: top candidate is database");
  ok(inc.candidates[0].evidence.length > 0 && inc.candidates[0].factors.length >= 5, "root cause has evidence + factor breakdown");
  ok(["auth-service", "payment-api", "transaction-service", "notification-service"].every(s => inc.affectedServices.includes(s)), "dependency impact covers auth, payment, transaction, notification");
  ok(/probab/i.test(inc.confidenceNote) && /causation/i.test(inc.summary.caveat), "labels score as heuristic and warns about causation");

  r = await upload("02-gateway-failure.jsonl", fs.readFileSync(path.join(dir, "02-gateway-failure.jsonl")));
  ok(r.status === 200, "upload .jsonl");
  r = await call("GET", "/api/dashboard"); ok(r.json.incidents.length === 2 && r.json.incidents.some(i => i.rootCause === "api-gateway"), "second incident ranks api-gateway");
  r = await upload("03-healthy-baseline.log", fs.readFileSync(path.join(dir, "03-healthy-baseline.log")));
  r = await call("GET", "/api/dashboard"); ok(r.json.incidents.length === 2, "healthy baseline creates no incident");

  r = await upload("04-malformed-mixed.log", fs.readFileSync(path.join(dir, "04-malformed-mixed.log")));
  ok(r.status === 200 && r.json.skipped >= 3 && r.json.stats.malformedSamples.length > 0, "malformed lines skipped and reported");
  r = await upload("bad.exe", "hello"); ok(r.status === 400, "rejects unsupported extension");
  r = await upload("empty.log", ""); ok(r.status === 400, "rejects empty file");
  r = await upload("junk.log", "not a log\nstill not\n"); ok(r.status === 422, "rejects file with no valid events");
  r = await upload("bin.log", Buffer.from([1, 2, 0, 3, 0, 4])); ok(r.status === 400, "rejects binary file");

  const id = (await call("GET", "/api/incidents")).json[0].id;
  r = await call("GET", `/api/incidents/${id}`); ok(r.status === 200 && r.json.timeline.length > 0, "incident detail API");
  r = await call("GET", "/api/incidents/INC-nope"); ok(r.status === 404, "unknown incident 404");
  for (const f of ["md", "html", "json"]) {
    r = await call("GET", `/api/incidents/${id}/report?format=${f}`);
    ok(r.status === 200 && /attachment/.test(r.headers.get("content-disposition") || "") && r.text.includes(id), "report download " + f);
  }
  r = await call("GET", "/api/events?service=database&level=ERROR"); ok(r.json.events.length > 0 && r.json.events.every(e => e.service === "database"), "events filter API");
  r = await call("GET", "/api/topology"); ok(r.json.services.length >= 5 && r.json.dependencies["auth-service"], "topology API");
  r = await call("POST", "/api/analyze"); ok(r.status === 200, "re-analyze");

  await call("DELETE", "/api/reset");
  r = await call("POST", "/api/simulate", { scenario: "db-exhaustion" }); ok(r.status === 200 && r.json.added > 10, "simulate scenario");
  r = await call("GET", "/api/dashboard"); const sim = r.json.incidents[0];
  ok(sim && sim.rootCause === "database" && sim.affectedServices.includes("notification-service"), "simulation: DB exhaustion → auth/payment/transaction/notification");

  await call("DELETE", "/api/reset");
  r = await call("POST", "/api/live/start", { scenario: "db-exhaustion", intervalMs: 300 }); ok(r.status === 200 && r.json.running, "live feed starts");
  await new Promise(res => setTimeout(res, 1200));
  r = await call("GET", "/api/live/status"); ok(r.json.emitted >= 3, "live feed emits events (" + r.json.emitted + ")");
  r = await call("POST", "/api/live/stop"); ok(!r.json.running, "live feed stops");
  r = await call("POST", "/api/live/start", { scenario: "nope" }); ok(r.status === 400, "live rejects unknown scenario");
  r = await call("POST", "/api/simulate", "{bad", "{bad"); ok(r.status === 400 || r.status === 200, "bad body handled");

  // ---- v2: security headers, ingestion, AI fallback, history ----
  r = await call("GET", "/api/health"); ok(/default-src 'self'/.test(r.headers.get("content-security-policy") || "") && r.headers.get("x-content-type-options") === "nosniff" && !r.headers.get("x-powered-by"), "security headers present");
  r = await fetch(BASE + "/api/ingest", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ events: [] }) }); ok([401, 503].includes(r.status), "ingest without API key rejected (" + r.status + ")");
  r = await call("POST", "/api/simulate", { scenario: "db-exhaustion" }, null);
  r = await fetch(BASE + "/api/simulate", { method: "POST", headers: { cookie, "Content-Type": "application/json", Origin: "http://evil.example" }, body: "{}" }); ok(r.status === 403, "cross-origin write blocked");
  const KEY = process.env.INGEST_API_KEY;
  if (KEY) {
    const ing = (body, type = "application/json") => fetch(BASE + "/api/ingest", { method: "POST", headers: { "x-api-key": KEY, "Content-Type": type }, body: typeof body === "string" ? body : JSON.stringify(body) }).then(async x => ({ status: x.status, json: await x.json() }));
    const ev = { timestamp: new Date(Date.now() - 3600e3).toISOString(), service: "db", level: "error", message: "e2e pool exhausted " + Date.now() };
    r = await ing({ events: [ev, { message: "no timestamp" }] }); ok(r.status === 201 && r.json.accepted === 1 && r.json.rejected === 1, "ingest accepts valid, rejects invalid");
    r = await ing({ events: [ev] }); ok(r.status === 200 && r.json.duplicates === 1 && r.json.accepted === 0, "ingest de-duplicates");
    r = await ing("2026-11-09T11:00:00Z ERROR payment-api could not acquire database connection", "text/plain"); ok(r.status === 201, "ingest accepts text/plain log lines");
    r = await ing({ nope: true }); ok(r.status === 400, "ingest validates body shape");
    r = await fetch(BASE + "/api/ingest", { method: "POST", headers: { "x-api-key": "wrong-wrong-wrong-wrong", "Content-Type": "application/json" }, body: "{}" }); ok(r.status === 401, "ingest rejects wrong key");
  } else console.log("SKIP ingestion checks (set INGEST_API_KEY and start the server with INGEST_API_KEYS)");
  await call("DELETE", "/api/reset"); await call("POST", "/api/simulate", { scenario: "db-exhaustion" });
  r = await call("GET", "/api/dashboard"); const di = r.json.incidents[0];
  ok(di.hypotheses.length > 0 && di.uncertainty && di.impactAnalysis, "dashboard exposes hypotheses, uncertainty and impact analysis");
  ok(r.json.ai && !("apiKey" in r.json.ai) && !/sk-/.test(JSON.stringify(r.json)), "dashboard never exposes AI key");
  r = await call("POST", `/api/incidents/${di.id}/ai`, {}); ok(r.status === 200 && ["ai", "engine"].includes(r.json.source) && r.json.analysis.summary && r.json.guardrails.autoExecute === false, "AI endpoint returns analysis (source: " + (r.json && r.json.source) + ")");
  r = await call("POST", "/api/incidents/bad-id/ai", {}); ok(r.status === 400, "AI endpoint validates incident id");
  r = await call("GET", "/api/history"); ok(r.status === 200 && Array.isArray(r.json.incidents), "history API");
  r = await call("GET", `/api/incidents/${di.id}/report?format=md`); ok(/Hypotheses: evidence for and against/.test(r.text), "report includes hypotheses and uncertainty");
  console.log(failed ? `\n${failed} check(s) failed` : "\nAll checks passed"); process.exit(failed ? 1 : 0);
})().catch(e => { console.error("Test crashed:", e.message); process.exit(1); });
