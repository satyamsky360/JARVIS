// Unit/integration tests for the library layer. No server, network or API key needed. Run: npm test
process.env.NODE_NO_WARNINGS = "1";
const fs = require("fs"), os = require("os"), path = require("path");
const { parseContent } = require("../lib/parser");
const { analyzeEvents } = require("../lib/analyzer");
const ai = require("../lib/ai");
const { normalizeBatch } = require("../lib/ingest");
const store = require("../lib/store");
const dbm = require("../lib/db");
const { rateLimit } = require("../lib/ratelimit");
const { requireApiKey, redact, sameOriginWrites, securityHeaders } = require("../lib/security");
const { settings } = require("../lib/env");
const report = require("../lib/report");

let failed = 0, n = 0;
const ok = (c, m) => { n++; console.log((c ? "PASS " : "FAIL ") + m); if (!c) failed++; };
const sample = f => fs.readFileSync(path.join(__dirname, "..", "sample-data", f), "utf8");
const load = (f, name = f) => { const { events } = parseContent(sample(f), name); events.forEach((e, i) => { e.id = "e" + (i + 1); e.seq = i + 1; }); return events; };
const mockRes = () => ({ code: 200, headers: {}, body: null, status(c) { this.code = c; return this; }, setHeader(k, v) { this.headers[k.toLowerCase()] = v; }, json(b) { this.body = b; } });
const jsonRes = body => async () => ({ ok: true, status: 200, json: async () => body });
const anthropicReply = obj => jsonRes({ content: [{ type: "text", text: typeof obj === "string" ? obj : JSON.stringify(obj) }] });
const CFG = { provider: "anthropic", apiKey: "sk-test-SECRET-123456", model: "m1", baseUrl: "", timeoutMs: 500, maxTokens: 500 };

(async () => {
  // ---------- root-cause analysis ----------
  const inc = analyzeEvents(load("01-payment-outage.log"))[0];
  ok(inc.rootCause === "database", "analysis: database ranked first on payment outage");
  ok(inc.hypotheses.length >= 2 && inc.hypotheses.length <= 4, "analysis: multiple hypotheses produced");
  const h0 = inc.hypotheses[0], h1 = inc.hypotheses[1];
  ok(h0.evidenceFor.length > 3 && h0.evidenceFor.some(x => x.eventId), "analysis: evidence-for includes cited log events");
  ok(h1.evidenceAgainst.length > 0 && h1.evidenceAgainst.some(x => /below the leading/.test(x.text)), "analysis: runner-up lists evidence against");
  ok(h0.status === "leading" && /unconfirmed/.test(h0.statement), "analysis: hypotheses are labelled unconfirmed");
  ok(h0.impact.affected.includes("payment-api") && h0.impact.blastRadiusPct > 0 && h0.impact.paths.length > 0, "analysis: impact analysis (affected, blast radius, paths)");
  ok(["Low", "Medium", "High"].includes(inc.uncertainty.level) && inc.uncertainty.cannotDetermine.length > 0 && /not a probability/.test(inc.uncertainty.note), "analysis: uncertainty reported and not presented as probability");
  const lone = analyzeEvents(parseContent("2026-11-09T10:00:00Z ERROR payment-api boom failed\n2026-11-09T10:00:05Z ERROR payment-api boom again failed\n", "x.log").events.map((e, i) => ({ ...e, id: "e" + i, seq: i })))[0];
  ok(lone && lone.uncertainty.reasons.some(r => r.code === "single-service") && lone.uncertainty.level !== "Low", "analysis: single-service incident flags high uncertainty");
  ok(lone.uncertainty.reasons.some(r => r.code === "missing-logs"), "analysis: services with no logs are listed as unknown");

  // ---------- AI: success path, validation, guardrails ----------
  const good = { summary: "The database pool warned first; dependents then failed.", leadingHypothesis: { service: "database", reasoning: "Pool warning came first.", citedEventIds: ["e1"] },
    alternativeHypotheses: [{ service: "payment-api", reasoning: "Failed early but depends on database.", citedEventIds: [] }], impactExplanation: "Auth and payment were affected.",
    recommendations: [{ action: "Check connection pool usage.", rationale: "Pool warnings.", citedEventIds: ["e1"] }], openQuestions: ["Was there a deploy?"] };
  let calls = 0, lastReq = null;
  const spy = async (url, opt) => { calls++; lastReq = { url, opt }; return (await anthropicReply(good)()); };
  let r = await ai.analyze(inc, { cfg: CFG, fetchImpl: spy });
  ok(r.source === "ai" && r.provider === "anthropic" && r.analysis.leadingHypothesis.service === "database", "ai: successful response used");
  ok(lastReq.opt.headers["x-api-key"] === CFG.apiKey && /api\.anthropic\.com\/v1\/messages$/.test(lastReq.url), "ai: key sent server-side to provider only");
  const sent = JSON.parse(lastReq.opt.body).messages[0].content;
  ok(/EVIDENCE/.test(sent) && sent.includes('"hypotheses"') && !sent.includes(CFG.apiKey), "ai: prompt contains evidence packet, never the key");
  ok(r.analysis.recommendations.every(x => x.manual === true) && r.guardrails.autoExecute === false, "ai: recommendations flagged manual, never auto-executed");
  r = await ai.analyze(inc, { cfg: CFG, fetchImpl: spy });
  ok(r.cached === true && calls === 1, "ai: identical evidence served from cache (no second API call)");
  r = await ai.analyze(inc, { cfg: CFG, fetchImpl: spy, refresh: true });
  ok(calls === 2 && r.cached === false, "ai: refresh bypasses cache");

  ai._memo.clear();
  const bad = { ...good, summary: "This is the confirmed root cause, definitely.", leadingHypothesis: { service: "database", reasoning: "It is the root cause.", citedEventIds: ["e1", "e99999"] } };
  r = await ai.analyze(inc, { cfg: CFG, fetchImpl: anthropicReply(bad) });
  ok(r.source === "ai" && !/confirmed root cause|definitely/i.test(r.analysis.summary), "ai: overconfident wording softened");
  ok(!r.analysis.leadingHypothesis.citedEventIds.includes("e99999") && r.guardrails.droppedCitations >= 1, "ai: citations to non-existent events dropped");
  ai._memo.clear();
  r = await ai.analyze(inc, { cfg: CFG, fetchImpl: anthropicReply({ ...good, leadingHypothesis: { service: "made-up-svc", reasoning: "x", citedEventIds: [] } }) });
  ok(r.analysis.leadingHypothesis.service === "database" && r.guardrails.notes.some(x => /made-up-svc/.test(x)), "ai: invented service replaced by engine hypothesis");

  // ---------- AI: graceful fallback ----------
  const fallbacks = [
    ["HTTP error", async () => ({ ok: false, status: 503, json: async () => ({}) })],
    ["network error with key in message", async () => { throw new Error("connect failed " + CFG.apiKey); }],
    ["non-JSON text", anthropicReply("Sorry, I cannot help.")],
    ["missing fields", anthropicReply({ foo: 1 })],
    ["timeout", (url, opt) => new Promise((_, rej) => opt.signal.addEventListener("abort", () => rej(Object.assign(new Error("aborted"), { name: "AbortError" }))))]
  ];
  for (const [name, f] of fallbacks) {
    ai._memo.clear();
    r = await ai.analyze(inc, { cfg: CFG, fetchImpl: f });
    ok(r.source === "engine" && r.fallbackReason && r.analysis.summary && r.analysis.recommendations.length > 0, `ai fallback: ${name} -> engine analysis`);
    ok(!JSON.stringify(r).includes(CFG.apiKey), `ai fallback: ${name} does not leak the API key`);
  }
  r = await ai.analyze(inc, { cfg: { ...CFG, provider: "none", apiKey: "" } });
  ok(r.source === "engine" && /not configured/.test(r.fallbackReason), "ai: provider none -> engine, no network call");
  r = await ai.analyze(inc, { cfg: { ...CFG, apiKey: "" } });
  ok(r.source === "engine" && /AI_API_KEY/.test(r.fallbackReason), "ai: missing key -> engine");
  ok(!("apiKey" in ai.status(CFG)) && !JSON.stringify(ai.status(CFG)).includes(CFG.apiKey), "ai: status endpoint never exposes the key");
  ai._memo.clear();
  r = await ai.analyze(inc, { cfg: { ...CFG, provider: "openai-compatible", baseUrl: "http://localhost:11434/v1" }, fetchImpl: async (u, o) => { lastReq = { u, o }; return jsonRes({ choices: [{ message: { content: JSON.stringify(good) } }] })(); } });
  ok(r.source === "ai" && /localhost:11434\/v1\/chat\/completions$/.test(lastReq.u) && lastReq.o.headers.Authorization === "Bearer " + CFG.apiKey, "ai: configurable OpenAI-compatible provider/base URL");
  const pk = JSON.stringify(ai.buildPacket(inc));
  ok(!/sk-test/.test(pk) && ai.buildPacket(inc).events.length <= 60, "ai: evidence packet bounded and secret-free");
  ok(/never an instruction|untrusted/i.test(ai.buildPacket.toString() + require("fs").readFileSync(require.resolve("../lib/ai"), "utf8")), "ai: prompt treats log text as untrusted data");

  // ---------- ingestion ----------
  let b = normalizeBatch({ events: [{ timestamp: "2026-11-09T10:00:00Z", service: "DB", level: "err", message: "pool exhausted" }, { service: "x", message: "no ts" }, "junk", { timestamp: "nope", message: "m" }] });
  ok(b.events.length === 1 && b.events[0].service === "database" && b.events[0].level === "ERROR" && b.rejectedCount === 3, "ingest: normalizes aliases/levels, rejects invalid records");
  ok(normalizeBatch({ nope: 1 }).status === 400 && normalizeBatch({ events: [] }).status === 400 && normalizeBatch("  ").status === 400, "ingest: rejects bad shapes and empty bodies");
  ok(normalizeBatch({ events: new Array(11).fill({}) }, { maxBatch: 10 }).status === 413, "ingest: enforces batch size limit");
  b = normalizeBatch("2026-11-09T10:00:00Z ERROR payment-api could not acquire database connection\nbad line\n");
  ok(b.events.length === 1 && b.rejectedCount === 1, "ingest: text/plain lines parsed, bad lines counted");
  const longMsg = normalizeBatch({ events: [{ timestamp: "2026-11-09T10:00:00Z", service: "a", message: "x".repeat(50000) }] });
  ok(longMsg.events.length === 0 && longMsg.rejectedCount === 1, "ingest: oversize message rejected");

  // ---------- persistence ----------
  const tmp = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "jarvis-")), "t.db");
  let db = dbm.create(tmp);
  ok(db.enabled, "persistence: SQLite available (" + (db.reason || "node:sqlite") + ")");
  if (db.enabled) {
    store.attach(db); store.clear();
    const evs = load("01-payment-outage.log");
    let res = store.add(evs, "t"); const total = res.added;
    res = store.add(load("01-payment-outage.log"), "t");
    ok(total > 20 && res.added === 0 && res.duplicates === total, "persistence: de-duplicates across batches");
    const incs = analyzeEvents(store.all()); db.upsertIncidents(incs);
    db.saveAi(incs[0].id, "fp1", { source: "ai", provider: "p", model: "m", analysis: { summary: "s" } });
    db.close();
    db = dbm.create(tmp); const loaded = store.attach(db);
    ok(loaded === total && store.all().length === total, "persistence: events survive restart");
    ok(db.listIncidents().length === incs.length && db.getIncident(incs[0].id).snapshot.rootCause === "database", "persistence: incident history survives restart");
    ok(db.getAi(incs[0].id, "fp1").analysis.summary === "s" && db.getAi(incs[0].id, "other") === null, "persistence: AI results cached by fingerprint");
    ok(store.add(load("01-payment-outage.log"), "t").added === 0, "persistence: restart does not re-add stored events");
    store.clear(); db.close(); db = dbm.create(tmp); ok(store.attach(db) === 0 && db.listIncidents().length > 0, "persistence: reset clears events but keeps incident history");
    db.clearHistory(); ok(db.listIncidents().length === 0, "persistence: history can be wiped explicitly"); db.close();
  }
  store.attach(null); store.clear();

  // ---------- security ----------
  const rl = rateLimit({ max: 3, windowMs: 60000, key: () => "k" });
  const codes = []; for (let i = 0; i < 5; i++) { const res = mockRes(); rl({}, res, () => codes.push(200)); if (res.code === 429) codes.push(429); }
  ok(codes.join() === "200,200,200,429,429", "security: rate limiter returns 429 after the limit");
  const keyMw = requireApiKey(() => ["abcdefghijklmnop1234"]);
  const run = headers => { const res = mockRes(); let passed = false; const req = { headers }; keyMw(req, res, () => { passed = true; }); return { res, passed, req }; };
  ok(run({}).res.code === 401 && run({ "x-api-key": "wrong" }).res.code === 401, "security: missing/wrong API key rejected");
  ok(run({ "x-api-key": "abcdefghijklmnop1234" }).passed && run({ authorization: "Bearer abcdefghijklmnop1234" }).passed, "security: valid key accepted (header or Bearer)");
  ok(requireApiKey(() => [])({ headers: {} }, (() => { const r = mockRes(); global.__r = r; return r; })(), () => {}) === undefined && global.__r.code === 503, "security: ingestion disabled when no keys configured");
  ok(!JSON.stringify(run({ "x-api-key": "abcdefghijklmnop1234" }).req.ingestClient).includes("abcdefghijklmnop"), "security: client id is a hash, not the key");
  ok(redact("fail sk-abcdefghijk and Bearer abcdefghijkl and mykey123", ["mykey123"]).match(/redacted/g).length === 3, "security: redact strips keys/tokens");
  let res = mockRes(); sameOriginWrites({ method: "POST", headers: { origin: "http://evil.example", host: "localhost:3000" } }, res, () => {});
  ok(res.code === 403, "security: cross-origin write blocked");
  let pass = false; sameOriginWrites({ method: "POST", headers: { origin: "http://localhost:3000", host: "localhost:3000" } }, mockRes(), () => { pass = true; }); ok(pass, "security: same-origin write allowed");
  res = mockRes(); securityHeaders({ path: "/api/x" }, res, () => {});
  ok(/default-src 'self'/.test(res.headers["content-security-policy"]) && res.headers["x-frame-options"] === "DENY" && res.headers["cache-control"] === "no-store", "security: CSP, frame and cache headers set");
  ok(settings({ NODE_ENV: "production" }).problems.length >= 2, "config: production refuses default credentials/secret");
  ok(settings({ NODE_ENV: "production", HOST_PASS: "a-long-password-123", SESSION_SECRET: "x".repeat(40) }).problems.length === 0, "config: valid production settings accepted");
  ok(settings({ AI_PROVIDER: "bogus" }).problems.length === 1 && settings({ AI_PROVIDER: "openai-compatible" }).problems.length === 1, "config: invalid AI provider settings reported");
  ok(settings({ INGEST_API_KEYS: "short, 0123456789abcdefXYZ" }).ingestKeys.length === 1, "config: weak (short) ingest keys ignored");
  const clientCode = fs.readFileSync(path.join(__dirname, "..", "public", "index.html"), "utf8");
  ok(!/x-api-key|authorization|process\.env|sk-[a-z0-9]{8}/i.test(clientCode), "security: no API key handling in frontend code");
  const gi = fs.readFileSync(path.join(__dirname, "..", ".gitignore"), "utf8");
  ok(/^\.env$/m.test(gi) && /\.db/.test(gi), ".gitignore excludes .env and database files");

  // ---------- reports & existing behaviour ----------
  const withAi = report.render(inc, "md", { ai: ai.engineAnalysis(inc, "x"), uploads: [] }).body;
  ok(/Hypotheses: evidence for and against/.test(withAi) && /Uncertainty/.test(withAi) && /AI investigation/.test(withAi), "report: includes hypotheses, uncertainty, AI section");
  ok(["md", "html", "json"].every(f => report.render(inc, f, { uploads: [] }).body.includes(inc.id)), "report: md/html/json render");
  const g = analyzeEvents(load("02-gateway-failure.jsonl", "02.jsonl"));
  ok(g.some(i => i.rootCause === "api-gateway"), "existing: gateway failure sample still ranks api-gateway");
  ok(analyzeEvents(load("03-healthy-baseline.log")).length === 0, "existing: healthy baseline creates no incident");
  const { burst } = require("../lib/scenarios");
  ok(analyzeEvents(burst("db-exhaustion").map((e, i) => ({ ...e, id: "e" + i, seq: i })))[0].rootCause === "database", "existing: simulation scenario still works");

  console.log(failed ? `\n${failed} of ${n} check(s) failed` : `\nAll ${n} checks passed`); process.exit(failed ? 1 : 0);
})().catch(e => { console.error("Test crashed:", e); process.exit(1); });
