const { loadDotEnv, settings } = require("./lib/env");
loadDotEnv();
const express = require("express");
const multer = require("multer");
const path = require("path");
const cfg = settings();
if (cfg.problems.length) { console.error("Configuration problems:\n - " + cfg.problems.join("\n - ")); if (cfg.production || cfg.problems.some(p => p.startsWith("AI_"))) process.exit(1); }

const app = express();
const PORT = cfg.port;
app.disable("x-powered-by");
if (cfg.trustProxy) app.set("trust proxy", 1);
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 }
});

const { securityHeaders, sameOriginWrites, requireApiKey } = require("./lib/security");
const { rateLimit } = require("./lib/ratelimit");
app.use(securityHeaders);
app.use(express.static(path.join(__dirname, "public")));
app.use("/api", rateLimit({ max: cfg.rate.apiPerMin, key: req => req.ip }));
app.use("/api", sameOriginWrites);
// Ingestion authenticates BEFORE any body is parsed, so unauthenticated callers cannot make the server buffer payloads.
const ingestLimiter = rateLimit({ max: cfg.rate.ingestPerMin, key: req => req.ingestClient || req.ip, message: "Ingestion rate limit exceeded. Retry shortly." });
app.use("/api/ingest", requireApiKey(() => cfg.ingestKeys), ingestLimiter, express.text({ type: ["text/plain", "application/x-ndjson"], limit: "2mb" }));
app.use(express.json({ limit: "2mb" }));

const { SERVICES: services, DEPENDENCIES: dependencies, ALLOWED_EXTENSIONS, MAX_UPLOAD_BYTES } = require("./lib/config");
const { parseContent } = require("./lib/parser");
const { analyzeEvents } = require("./lib/analyzer");
const { listScenarios, burst } = require("./lib/scenarios");
const store = require("./lib/store");
const live = require("./lib/live");
const report = require("./lib/report");
const { normalizeBatch } = require("./lib/ingest");
const ai = require("./lib/ai");
const dbm = require("./lib/db");
const db = dbm.create(cfg.dbPath);
const loaded = store.attach(db);
console.log(db.enabled ? `Persistence: SQLite at ${cfg.dbPath} (${loaded} events loaded).` : `Persistence disabled: ${db.reason}`);

// Incidents are recomputed only when the event store changes.
let cache = { version: -1, incidents: [] };
function currentIncidents() {
  if (cache.version !== store.version()) {
    cache = { version: store.version(), incidents: analyzeEvents(store.all()) };
    try { if (db.enabled && cache.incidents.length) db.upsertIncidents(cache.incidents); } catch (e) { console.error("History error:", e.message); }
  }
  return cache.incidents;
}
const publicEvent = e => ({ id: e.id, timestamp: e.timestamp, service: e.service, level: e.level, message: e.message, source: e.source, patterns: e.patterns });
const metrics = () => ({
  activeIncidents: currentIncidents().length, servicesMonitored: services.length,
  eventsAnalyzed: store.all().length, errors: store.all().filter(e => e.level === "ERROR").length
});

function seedDemo() { if (!store.all().length) store.add(burst("db-exhaustion"), "demo-seed"); } // only on an empty workspace
seedDemo();

// ---------- Host authentication ----------
// Credentials come from env vars. Defaults are for local demos only.
const crypto = require("crypto");
const HOST_USER = cfg.hostUser;
const HOST_PASS = cfg.hostPass;
const USING_DEFAULT_LOGIN = cfg.usingDefaultLogin;
const SECRET = cfg.sessionSecret || crypto.randomBytes(32).toString("hex");
const SESSION_MS = 8 * 60 * 60 * 1000;
const COOKIE = "jarvis_session";
const attempts = new Map(); // ip -> { count, lockedUntil }

const sign = payload => crypto.createHmac("sha256", SECRET).update(payload).digest("base64url");
const sameText = (a, b) => crypto.timingSafeEqual(
  crypto.createHash("sha256").update(String(a)).digest(),
  crypto.createHash("sha256").update(String(b)).digest());
function makeToken(user) {
  const payload = Buffer.from(JSON.stringify({ u: user, exp: Date.now() + SESSION_MS })).toString("base64url");
  return payload + "." + sign(payload);
}
function readToken(token) {
  if (!token) return null;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return null;
  const expected = sign(payload);
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    return data.exp > Date.now() ? data : null;
  } catch (_) { return null; }
}
function getCookie(req, name) {
  const hit = (req.headers.cookie || "").split(";").map(s => s.trim()).find(s => s.startsWith(name + "="));
  return hit ? decodeURIComponent(hit.slice(name.length + 1)) : null;
}
function cookieHeader(value, maxAgeSec) {
  return `${COOKIE}=${encodeURIComponent(value)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAgeSec}` +
    (cfg.production ? "; Secure" : "");
}
function requireHost(req, res, next) {
  const session = readToken(getCookie(req, COOKIE));
  if (!session) return res.status(401).json({ error: "Host sign-in required." });
  req.hostUser = session.u;
  next();
}

app.get("/api/health", (req, res) => res.json({ status: "ok", service: "J.A.R.V.I.S. API", timestamp: new Date().toISOString() }));
app.get("/api/session", (req, res) => {
  const session = readToken(getCookie(req, COOKIE));
  res.json({ authenticated: !!session, user: session ? session.u : null });
});
app.post("/api/login", rateLimit({ max: cfg.rate.loginPerMin, key: req => req.ip, message: "Too many sign-in requests. Try again in a minute." }), (req, res) => {
  const record = attempts.get(req.ip) || { count: 0, lockedUntil: 0 };
  if (record.lockedUntil > Date.now()) return res.status(429).json({ error: "Too many attempts. Try again in a minute." });
  const { username = "", password = "" } = req.body || {};
  if (typeof username !== "string" || typeof password !== "string" || username.length > 200 || password.length > 500) return res.status(400).json({ error: "Invalid credentials format." });
  const userOk = sameText(username, HOST_USER);
  const passOk = sameText(password, HOST_PASS);
  if (!(userOk && passOk)) {
    record.count += 1;
    if (record.count >= 5) { record.lockedUntil = Date.now() + 60 * 1000; record.count = 0; }
    attempts.set(req.ip, record);
    return res.status(401).json({ error: "Incorrect username or password." });
  }
  attempts.delete(req.ip);
  res.setHeader("Set-Cookie", cookieHeader(makeToken(HOST_USER), SESSION_MS / 1000));
  res.json({ user: HOST_USER });
});
app.post("/api/logout", (req, res) => {
  res.setHeader("Set-Cookie", cookieHeader("", 0));
  res.json({ ok: true });
});

// ---------- External log ingestion (API-key protected, no browser session) ----------
app.post("/api/ingest", (req, res) => {
  const batch = normalizeBatch(req.body, { maxBatch: cfg.ingestMaxBatch });
  if (batch.error) return res.status(batch.status).json({ error: batch.error });
  if (!batch.events.length) return res.status(422).json({ error: "No valid events in request.", received: batch.received, rejected: batch.rejected });
  const { added, duplicates } = store.add(batch.events, "api:" + req.ingestClient);
  try { db.logIngest({ client: req.ingestClient, received: batch.received, accepted: added, duplicates, rejected: batch.rejectedCount }); } catch (_) {}
  res.status(added ? 201 : 200).json({ received: batch.received, accepted: added, duplicates, rejected: batch.rejectedCount, rejectedSamples: batch.rejected, incidents: currentIncidents().length });
});
app.use("/api", requireHost); // everything below needs a signed-in host
app.get("/api/dashboard", (req, res) => {
  const incidents = currentIncidents();
  res.json({
    metrics: metrics(), incidents,
    events: [...store.all()].sort((a, b) => b.ts - a.ts).slice(0, 30).map(publicEvent),
    services, dependencies, uploads: store.uploads(), live: live.status(), scenarios: listScenarios(),
    ai: ai.status(cfg.ai), persistence: { enabled: db.enabled, ...db.stats() }, ingestEnabled: cfg.ingestKeys.length > 0
  });
});

app.get("/api/topology", (req, res) => {
  const counts = {};
  for (const e of store.all()) counts[e.service] = (counts[e.service] || 0) + 1;
  res.json({ services, dependencies, eventCounts: counts });
});

app.get("/api/events", (req, res) => {
  const { service, level, q, from, to, since } = req.query;
  const limit = Math.min(1000, Math.max(1, parseInt(req.query.limit, 10) || 200));
  const f = from ? Date.parse(from) : null, t = to ? Date.parse(to) : null, sinceSeq = parseInt(since, 10) || 0;
  if ((from && Number.isNaN(f)) || (to && Number.isNaN(t))) return res.status(400).json({ error: "from/to must be ISO timestamps." });
  const needle = q ? String(q).toLowerCase() : null;
  const rows = store.all().filter(e =>
    (!service || e.service === service) && (!level || e.level === String(level).toUpperCase()) &&
    (f === null || e.ts >= f) && (t === null || e.ts <= t) && e.seq > sinceSeq && (!needle || e.message.toLowerCase().includes(needle)));
  rows.sort((a, b) => a.ts - b.ts);
  res.json({ total: rows.length, events: rows.slice(-limit).map(e => ({ ...publicEvent(e), seq: e.seq })) });
});

app.get("/api/incidents", (req, res) => {
  res.json(currentIncidents().map(({ timeline, candidates, correlations, ...rest }) => ({ ...rest, candidateCount: candidates.length })));
});
const findIncident = id => currentIncidents().find(i => i.id === id);
const ID_RE = /^INC-[0-9]{8}-[0-9]{6}$/;
const aiLimiter = rateLimit({ max: cfg.rate.aiPerMin, key: req => req.hostUser || req.ip, message: "AI analysis rate limit reached. Retry in a minute." });
// Only reuse an already-generated AI result in reports; downloading a report never triggers a paid API call.
const lastAi = new Map();
function cachedAi(inc) { const h = lastAi.get(inc.id); return h && h.events === inc.relatedEvents ? h.result : null; }
app.get("/api/ai/status", (req, res) => res.json(ai.status(cfg.ai)));
app.post("/api/incidents/:id/ai", aiLimiter, async (req, res, next) => {
  try {
    if (!ID_RE.test(req.params.id)) return res.status(400).json({ error: "Invalid incident id." });
    const inc = findIncident(req.params.id);
    if (!inc) return res.status(404).json({ error: "Incident not found. It may have changed after new events arrived." });
    const result = await ai.analyze(inc, { cfg: cfg.ai, db, refresh: !!(req.body && req.body.refresh === true) });
    lastAi.set(inc.id, { events: inc.relatedEvents, result });
    res.json(result);
  } catch (e) { next(e); }
});
app.get("/api/history", (req, res) => {
  const limit = Math.min(200, Math.max(1, parseInt(req.query.limit, 10) || 50));
  res.json({ persistence: db.enabled, incidents: db.listIncidents(limit), note: db.enabled ? undefined : db.reason });
});
app.get("/api/history/:id", (req, res) => {
  if (!ID_RE.test(req.params.id)) return res.status(400).json({ error: "Invalid incident id." });
  const row = db.getIncident(req.params.id);
  if (!row) return res.status(404).json({ error: "Incident not in history." });
  res.json(row);
});
app.get("/api/incidents/:id", (req, res) => {
  const inc = findIncident(req.params.id);
  if (!inc) return res.status(404).json({ error: "Incident not found. It may have changed after new events arrived." });
  res.json(inc);
});
app.get("/api/incidents/:id/report", (req, res) => {
  const inc = findIncident(req.params.id);
  if (!inc) return res.status(404).json({ error: "Incident not found." });
  const format = ["md", "html", "json"].includes(req.query.format) ? req.query.format : "md";
  const out = report.render(inc, format, { uploads: store.uploads(), eventsAnalyzed: store.all().length, ai: cachedAi(inc) });
  res.setHeader("Content-Type", out.type);
  res.setHeader("Content-Disposition", `attachment; filename="${inc.id}-report.${out.ext}"`);
  res.send(out.body);
});

// Upload validation: extension, size (multer), non-empty, text-only, at least one parsable event.
function uploadMiddleware(req, res, next) {
  upload.single("logfile")(req, res, err => {
    if (!err) return next();
    const tooBig = err.code === "LIMIT_FILE_SIZE";
    res.status(tooBig ? 413 : 400).json({ error: tooBig ? `File too large (max ${MAX_UPLOAD_BYTES / 1048576} MB).` : "Upload failed: " + err.message });
  });
}
app.post("/api/logs", uploadMiddleware, (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).json({ error: "Choose a log file first." });
  const name = path.basename(file.originalname || "upload");
  const ext = path.extname(name).toLowerCase();
  if (!ALLOWED_EXTENSIONS.includes(ext)) return res.status(400).json({ error: `Unsupported file type "${ext || "none"}". Allowed: ${ALLOWED_EXTENSIONS.join(", ")}` });
  if (!file.buffer.length) return res.status(400).json({ error: "The file is empty." });
  if (file.buffer.subarray(0, 8192).includes(0)) return res.status(400).json({ error: "This looks like a binary file, not a text log." });
  const { events, stats } = parseContent(file.buffer.toString("utf8").replace(/^\uFEFF/, ""), name);
  if (!events.length) return res.status(422).json({ error: "No valid log events found. Each line needs a timestamp.", stats });
  const { added, duplicates } = store.add(events, name);
  const info = { filename: name, lines: stats.lines, parsed: stats.parsed, skipped: stats.skipped, duplicates, added };
  store.recordUpload(info);
  const warnings = [];
  if (stats.skipped) warnings.push(`${stats.skipped} malformed line(s) were skipped.`);
  if (stats.inferredLevels) warnings.push(`${stats.inferredLevels} event(s) had no severity; it was inferred from the message.`);
  if (stats.unknownService) warnings.push(`${stats.unknownService} event(s) had no service name and are labeled "unknown".`);
  if (duplicates) warnings.push(`${duplicates} duplicate event(s) were ignored.`);
  res.json({ message: "Log file processed.", ...info, stats, warnings, incidents: currentIncidents().length, metrics: metrics() });
});

app.post("/api/simulate", (req, res) => {
  const scenario = (req.body && req.body.scenario) || "db-exhaustion";
  const events = burst(scenario);
  if (!events) return res.status(400).json({ error: "Unknown scenario." });
  const r = store.add(events, "simulation");
  res.json({ message: "Incident scenario simulated.", added: r.added, incidents: currentIncidents().length, metrics: metrics() });
});

app.post("/api/analyze", (req, res) => {
  cache.version = -1; // force a fresh pass
  const incidents = currentIncidents();
  res.json({ analyzedAt: new Date().toISOString(), incidents: incidents.length, eventCount: store.all().length, topRootCauses: incidents.map(i => ({ id: i.id, rootCause: i.rootCause, score: i.confidence })) });
});

app.get("/api/live/status", (req, res) => res.json({ ...live.status(), version: store.version() }));
app.post("/api/live/start", (req, res) => {
  try { res.json(live.start((req.body && req.body.scenario) || "db-exhaustion", req.body && req.body.intervalMs)); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
app.post("/api/live/stop", (req, res) => { live.stop(false); res.json(live.status()); });

app.delete("/api/reset", (req, res) => {
  live.stop(false); store.clear();
  if (req.query.history === "1") { db.clearHistory(); lastAi.clear(); }
  res.json({ message: "Workspace cleared.", metrics: metrics() });
});

// JSON error handling (malformed request bodies, unexpected errors)
app.use("/api", (req, res) => res.status(404).json({ error: "Unknown API route." }));
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  const bad = err.type === "entity.parse.failed", big = err.type === "entity.too.large";
  if (!bad && !big) console.error(err.message);
  res.status(bad ? 400 : big ? 413 : 500).json({ error: bad ? "Malformed JSON request body." : big ? "Request body too large." : "Internal server error." });
});

app.listen(PORT, () => {
  console.log(`J.A.R.V.I.S. running at http://localhost:${PORT}`);
  const a = ai.status(cfg.ai); console.log(a.configured ? `AI explanations: ${a.provider} / ${a.model}` : "AI explanations: off (built-in engine only). Set AI_PROVIDER and AI_API_KEY to enable.");
  console.log(cfg.ingestKeys.length ? "External ingestion: enabled at POST /api/ingest" : "External ingestion: disabled (set INGEST_API_KEYS to enable).");
  if (USING_DEFAULT_LOGIN) console.log(`Host login (demo defaults): ${HOST_USER} / ${HOST_PASS}. Set HOST_USER and HOST_PASS to change.`);
});
