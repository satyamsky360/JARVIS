# J.A.R.V.I.S. — Incident Investigation Platform (Node.js + Express)

Investigates incidents in a simulated payment system: **Auth Service, Payment API, Transaction Service, Database Server, Notification Service** (plus an API Gateway).

## Run
Requires **Node.js 22.5+** (built-in SQLite; older Node still runs, but history is then in-memory only).
```
npm install
cp .env.example .env      # then edit (Windows: copy .env.example .env)
npm start                 # http://localhost:3000
npm test                  # unit/integration tests (no server, network or API key needed)
npm run test:e2e          # end-to-end test against a running server (start it with DB_PATH=:memory:)
```
Login defaults to `host` / `jarvis@123` for local demos. Set `HOST_USER`, `HOST_PASS`, `SESSION_SECRET` in `.env`. With `NODE_ENV=production` the server refuses to start without a strong password and secret.

## Configuration (`.env`, see `.env.example`)
| Area | Variables |
|---|---|
| AI explanations | `AI_PROVIDER` (`none` \| `anthropic` \| `openai` \| `openai-compatible`), `AI_API_KEY`, `AI_MODEL`, `AI_BASE_URL`, `AI_TIMEOUT_MS`, `AI_MAX_TOKENS` |
| External ingestion | `INGEST_API_KEYS` (comma-separated, each ≥16 chars; empty = endpoint disabled), `INGEST_MAX_BATCH` |
| Persistence | `DB_PATH` (default `data/jarvis.db`; `:memory:` for none) |
| Limits | `RATE_API_PER_MIN`, `RATE_LOGIN_PER_MIN`, `RATE_INGEST_PER_MIN`, `RATE_AI_PER_MIN` |

## What's new in v2
1. **Multi-hypothesis root cause** (`lib/hypotheses.js`): top candidates become hypotheses with evidence *for*, evidence *against / not explained*, data gaps, manual checks to confirm, impact (affected / at-risk / blast radius) and per-incident **uncertainty** (close calls, thin data, missing service logs, unexplained anomalies). Scores stay heuristic rankings, never probabilities.
2. **AI explanations** (`lib/ai.js`): provider/model are configurable. The server sends the model only an *evidence packet* built by the engine (hypotheses, evidence, impact, anomaly log lines with ids). The model must answer in a fixed JSON shape and cite event ids. Output is validated: unknown event ids are removed, invented service names replaced, overconfident wording ("confirmed", "definitely") softened, recommendations flagged *manual*. Log text is treated as untrusted data (prompt-injection mitigation). **If the API is missing, slow, errors or returns junk, the built-in engine analysis is shown instead** and the UI says so. Results are cached per evidence fingerprint. Keys live only in server environment variables and are redacted from errors.
3. **External ingestion** `POST /api/ingest` (API-key protected): validation, normalization (service aliases, severity, timestamps), batch limits, de-duplication.
4. **Persistence** (SQLite, `lib/db.js`): events, incident history snapshots, cached AI results, ingest log. Restarts keep data; the demo incident is only seeded into an empty workspace. *Reset workspace* clears events but keeps incident history (`DELETE /api/reset?history=1` wipes both).
5. **Dashboard**: AI investigation panel, hypothesis explorer, uncertainty box, impact analysis cards, dependency map, per-service timeline lanes, incident history table, reports (md/html/json) that include hypotheses, uncertainty and the latest AI result.
6. **Hardening**: security headers + CSP, same-origin check on writes, constant-time key/password comparison, rate limits (API, login, ingest, AI), body-size limits, config validation, JSON error handling, no key in any response/log.
7. Demo simulation, live feed, sample logs and uploads are unchanged.

## Ingesting real logs
Set `INGEST_API_KEYS=<long random key>` and restart. Then:
```
curl -X POST http://localhost:3000/api/ingest -H "x-api-key: $KEY" -H "Content-Type: application/json" \
  -d '{"events":[{"timestamp":"2026-11-09T10:02:05Z","service":"db","level":"error","message":"connection pool exhausted"}]}'

# or raw log lines
curl -X POST http://localhost:3000/api/ingest -H "Authorization: Bearer $KEY" -H "Content-Type: text/plain" --data-binary @sample-data/01-payment-outage.log
```
Responses: `201` (new events accepted), `200` (all duplicates), `400/413/422` (validation), `401` (bad key), `429` (rate limit), `503` (ingestion disabled). Body: `{received, accepted, duplicates, rejected, rejectedSamples, incidents}`. Use HTTPS (reverse proxy) when exposing this beyond localhost.

## 2-minute demo
1. Sign in. The dashboard opens with a seeded **database connection exhaustion** incident.
2. Click **Reset workspace**, then **Upload logs** and choose files from `sample-data/` (or drag & drop):
   `01-payment-outage.log` (DB pool exhaustion), `02-gateway-failure.jsonl` (expired TLS certificate), `03-healthy-baseline.log` (no incident), `04-malformed-mixed.log` (bad lines are skipped and reported).
3. Pick an incident chip, open **Why it ranks here** for each candidate, click map nodes, click candidates → **Show on map**, click timeline dots.
4. **Start live feed** streams simulated events (about 1/s); the dashboard polls and re-analyzes as they arrive.
5. **Download report** as Markdown, HTML or JSON.

## How the analysis works (no ML, no hardcoded results)
- **Parsing** (`lib/parser.js`): `.log`, `.txt`, `.jsonl`, `.json`; ISO / `YYYY-MM-DD HH:MM:SS,mmm` / epoch timestamps (no zone = UTC), logfmt, JSON fields (`timestamp|time|ts`, `service|app|component`, `level|severity`, `message|msg`). Lines without a valid timestamp are skipped, never invented.
- **Correlation** (`lib/analyzer.js`): anomalies (WARN/ERROR) are clustered in time (5 min gap = new incident), linked along the dependency graph, matched by error pattern (`lib/config.js`), and cross-referenced when one service's error text names a service it depends on.
- **Root-cause score (0-100, heuristic, not a probability):** earliest anomaly (25) + downstream impact via dependency graph (30) + cause-type signature in its own logs (20) + referenced by dependents (15) + persistence (10), minus up to 20 if one of its own dependencies failed first. Every factor and the log lines behind it are shown.
- **Impact:** transitive dependents of the hypothesis are *affected* (anomalies seen), *at risk* (no anomalies logged), or the service is *anomalous but not downstream*.
- **Summaries/recommendations** are templates filled from computed facts. Recommendations are manual suggestions; nothing is executed.

## API (all except health/session/login/logout/ingest require sign-in)
| Method | Route | Purpose |
|---|---|---|
| GET | `/api/dashboard` | metrics, incidents (full analysis), recent events, topology, live status |
| GET | `/api/topology` | services, dependencies, event counts |
| GET | `/api/events?service&level&q&from&to&since&limit` | filtered events |
| GET | `/api/incidents`, `/api/incidents/:id` | incident list / full detail |
| GET | `/api/incidents/:id/report?format=md\|html\|json` | downloadable report |
| POST | `/api/logs` (multipart `logfile`) | validated upload (.log .jsonl .txt .json, ≤5 MB) |
| POST | `/api/simulate` `{scenario}` | add a simulated incident |
| POST | `/api/analyze` | force re-analysis |
| GET/POST | `/api/live/status`, `/api/live/start`, `/api/live/stop` | simulated live feed |
| POST | `/api/incidents/:id/ai` `{refresh?}` | AI (or engine-fallback) investigation of an incident |
| GET | `/api/ai/status` | AI provider/model status (never the key) |
| GET | `/api/history`, `/api/history/:id` | persisted incident history |
| POST | `/api/ingest` | external log ingestion (**API key**, not session) |
| DELETE | `/api/reset[?history=1]` | clear events (optionally history too) |

## Layout
`server.js` (routes, auth) · `lib/config.js` · `lib/env.js` · `lib/parser.js` · `lib/ingest.js` · `lib/store.js` · `lib/db.js` · `lib/analyzer.js` · `lib/hypotheses.js` · `lib/ai.js` · `lib/security.js` · `lib/ratelimit.js` · `lib/scenarios.js` · `lib/live.js` · `lib/report.js` · `public/index.html` · `sample-data/` · `test/unit.js` · `test/smoke.js`

## Testing status
- `npm test` (67 checks): analysis/hypotheses/uncertainty, AI success + validation + 5 fallback modes + key-leak checks, ingestion, SQLite persistence across restart, rate limiting, API-key auth, headers, config validation, reports.
- `npm run test:e2e` drives the real HTTP server (needs `npm install`). In the sandbox this ZIP was built in there was no network, so Express could not be installed; the server wiring was verified in-process against a minimal Express stand-in, and `test/smoke.js` has **not** been run against real Express/multer here. Run `npm install && npm run test:e2e` once on your machine.
- Real AI providers were **not** called (no network/keys). The request formats follow each provider's public chat API and are unit-tested with mocked `fetch`; try it with your key and report any provider-specific issue.

## Limitations
- The in-memory working set is capped at 10,000 events (older events remain in SQLite but are not re-loaded into analysis). Duplicates (same time/service/message) are ignored.
- The dependency graph and patterns are static assumptions in `lib/config.js`; missing logs can hide the real origin.
- Heuristic rankings and AI text show correlation and explanation, not proven causation. Verify with metrics, traces and change history. Nothing is ever executed automatically.
- Rate limits and login lockout are per process and in memory (not shared across multiple instances). Single host login, no per-user accounts or audit log. SQLite is unencrypted; protect `data/`. Put the app behind HTTPS in production. Do not upload confidential production logs to third-party AI providers without approval: when AI is enabled, selected log lines are sent to the configured provider.
- Timestamps without a zone are treated as UTC; the UI shows UTC. `node:sqlite` is experimental in Node 22 (API may change).
